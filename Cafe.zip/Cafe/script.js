document.getElementById('searchInput').addEventListener('keyup', function(event) {
    const input = event.target.value.toUpperCase(); // Get the current value of the input
    const drinks = document.querySelector('#drinks .products-grid'); // Select the drinks grid
    const snacks = document.querySelector('#snacks .products-grid'); // Select the snacks grid
    const otherSections = document.querySelectorAll('main > section:not(#drinks, #snacks)'); // Select all other sections
    let drinksVisible = false;
    let snacksVisible = false;

    // Function to search within a section
    function searchItems(section, isVisible) {
        const products = section.querySelectorAll('.product'); // Select all products in the section
        products.forEach(function(product) {
            const productName = product.querySelector('.product-info h3').textContent.toUpperCase();
            if (productName.indexOf(input) > -1) {
                product.style.display = ""; // Show the product
                isVisible = true;
            } else {
                product.style.display = "none"; // Hide the product
            }
        });
        return isVisible;
    }

    // Apply search to drinks and snacks sections
    drinksVisible = searchItems(drinks, drinksVisible);
    snacksVisible = searchItems(snacks, snacksVisible);

    // Control the visibility of the entire sections based on the search results
    document.querySelector('#drinks').style.display = drinksVisible || input === "" ? "" : "none";
    document.querySelector('#snacks').style.display = snacksVisible || input === "" ? "" : "none";

    // Hide or show other sections based on whether there is any input
    otherSections.forEach(section => {
        section.style.display = input === "" ? "" : "none";
    });
});

// JavaScript for handling all cart and modal functionalities
document.addEventListener('DOMContentLoaded', function() {
    // Add to cart functionality
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function() {
            const productInfo = this.closest('.product-info');
            const productName = productInfo.querySelector('h3').innerText;
            const productPrice = parseFloat(productInfo.querySelector('.price').innerText.replace('$', ''));
            const productImage = this.closest('.product').querySelector('img').src;
            
            // Check if item already exists in the cart
            let item = cart.find(item => item.name === productName);
            if (item) {
                item.quantity++;
            } else {
                cart.push({ name: productName, image: productImage, price: productPrice, quantity: 1 });
            }
            updateCartPopup();
            showAddItemNotification(productName);
        });
    });

    // Manage modal open and close functionalities
    setupModalInteractions();
});

// Cart array to hold cart items
let cart = [];

// Function to update cart popup with items
function updateCartPopup() {
    const cartItemsList = document.getElementById('cartItemsList');
    cartItemsList.innerHTML = '';
    let total = 0;
    cart.forEach((item, index) => {
        total += item.price * item.quantity;
        const li = document.createElement('li');
        li.innerHTML = `
            <img src="${item.image}" alt="${item.name}" style="width:50px; height:50px; border-radius: 50%;">
            ${item.name} x ${item.quantity} - $${(item.price * item.quantity).toFixed(2)}
            <button onclick="removeItemFromCart(${index})" class="remove-item-btn">Remove</button>
        `;
        cartItemsList.appendChild(li);
    });
    document.getElementById('totalPrice').innerText = `Total: $${total.toFixed(2)}`;
}

// Function to remove an item from the cart
function removeItemFromCart(index) {
    cart[index].quantity--;
    if (cart[index].quantity === 0) {
        cart.splice(index, 1);
    }
    updateCartPopup();
}

// Function to show a notification when an item is added to the cart
function showAddItemNotification(itemName) {
    let notification = document.getElementById('addItemNotification');
    notification.querySelector('p').innerText = `${itemName} added to the cart!`;
    notification.style.display = 'block';
    setTimeout(() => { notification.style.display = 'none'; }, 2000);
}

// Setup modal interactions for open and close functionalities
function setupModalInteractions() {
    // Close modal by clicking on close button
    document.querySelectorAll('.modal .close-button').forEach(button => {
        button.addEventListener('click', function() {
            this.closest('.modal').style.display = 'none';
        });
    });

    // Click outside modal content to close it
    window.onclick = function(event) {
        document.querySelectorAll('.modal').forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    };

    // Click on cart icon to open cart popup
    const cartIcon = document.querySelector('.cart-icon a');
    cartIcon.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent default anchor click behavior
        document.getElementById('cartPopup').style.display = 'block';
    });

    // Click on order now button to open order confirmation popup and clear cart
    const orderNowButton = document.querySelector('.order-now-btn');
    orderNowButton.addEventListener('click', function() {
        if (cart.length > 0) {
            document.getElementById('orderConfirmationPopup').style.display = 'block'; // Show order confirmation popup
            cart = []; // Clear the cart after ordering
            updateCartPopup(); // Update the cart display, which should now be empty
        }
    });
}

// Form submission handling for contact form
document.getElementById('contactForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;

    if (name && email && message) {
        // Display the thank you popup
        var modal = document.getElementById('thankYouPopup');
        modal.style.display = 'block';
    }
});

function showDeveloperInfo(name, email) {
    console.log('Function triggered for:', name);
    const popup = document.getElementById('developerPopup');
    const imageElement = document.getElementById('developerImage');
    const nameElement = document.getElementById('developerName');
    const emailElement = document.getElementById('developerEmail');

    if (popup && imageElement && nameElement && emailElement) {
        imageElement.src = document.querySelector(`img[alt="${name}"]`).src;
        nameElement.textContent = name;
        emailElement.textContent = email;
        popup.style.display = 'block';
        console.log('Popup should now be visible.');
    } else {
        console.error('Error: Element not found in the DOM.');
    }
}



// JavaScript function to close the modal
function closeModaldev() {
    var popup = document.getElementById('developerPopup'); 
    if (popup) {
        popup.style.display = 'none';
    } else {
        console.error('Popup element not found in the DOM.');
    }
}

// Event listener for closing the modal when clicking outside or on the close button
document.addEventListener('click', function(event) {
    var modal = document.getElementById('developerPopup');
    var closeButton = document.querySelector('.close-button');
    if (modal && closeButton && (event.target !== modal && !modal.contains(event.target) && event.target !== closeButton)) {
        modal.style.display = 'none';  // Hide the modal if clicked outside or on the close button
    }
});
